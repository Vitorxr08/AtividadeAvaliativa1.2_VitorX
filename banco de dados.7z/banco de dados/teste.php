<?php
include('conexaodb.php');
if($conexao){
    echo("Conexão criada com sucesso");
} else {
    echo("Não foi possivel conectar");
}
?>