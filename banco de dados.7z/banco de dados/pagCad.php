<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>bd_artista</title>
</head>
<body>
    <h1>Cadastro de artista</h1>
    <form action="" method="post">
        Livro: <input type="text" name="livro"><br>
        Disco: <input type="text" name="disco"><br>
        <input type="submit" value="Cadastrar">
    </form>
    <?php
    if($_POST){
        include('conexaodb.php');
        $livro=$_POST['livro'];
        $disco=$_POST['disco'];
        $sql="insert into artista (livro, disco)values('$livro','$disco');";
        $query=mysqli_query($conexao,$sql);
        if($query){
            echo("Gravado");
        }else{
            $m=mysqli_error($conexao);
            echo($m);
        }
    }
    ?>
</body>
</html>