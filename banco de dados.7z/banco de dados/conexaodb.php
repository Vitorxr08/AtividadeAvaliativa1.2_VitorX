<?php
$conexao=mysqli_connect('localhost','root','root','bd_artista');
?>